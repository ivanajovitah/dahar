<a href="/">
    <img src="assets/images/logo_nama_kotak.svg" style="width: 100%;min-width: 200px;" alt="logo">
</a><?php /**PATH C:\xampp\htdocs\skripsiNew\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>