<?php echo $__env->make('dashboard.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Select2 CSS --> 
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" /> 
<!-- Select2 JS --> 
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>


<style>
    .titleMealPlan{
        font-size: 2.5rem;
        font-weight: 600;
    }
    .sectionMarign{
        margin: 30px 0;
    }
    .coverImage{
        width: 100%;
        border-radius: 15px;
        margin-bottom: 30px;
    }
    .textJumlahSajian{
        font-weight: 400;
        color: grey;
    }
    #headerContainer{
        padding: 0 2em;
    }
    #detailContainer{
        padding: 0 3em;
    }
    .textLangkah, .textDetailInfo{
        color: black;
    }
    .textDetailInfo{
        margin-bottom: 0;
    }
    #containerDetailInfo{
        margin-bottom: 20px;
    }
    .likeMenu{
        font-size: 60px;
        color: pink;
        cursor: pointer;
    }
    #likeContainer{
        margin-right: 40px;
    }
    .saveMenu{
        font-size: 60px;
        cursor: pointer;
    }
    .detailSaveLike{
        margin-bottom: 20px;
    }
    .bahanContainer{
        margin-top: 30px;
    }
    .rowBahan{
        display: flex;
        width: 100%;
        margin: 10px 0;
    }
    .bahanQTY{
        width: 14%;
        display: flex;
        margin-right: 1%;
    }
    .select2-container{
        width: 80% !important;
    }
    .namaPlace{
        margin-right: 5px;
    }
    .but_read{
        height: 28px;
        padding: 0 5px;
        margin-left: 1%;
    }
    @media  screen and (max-width: 810px) {
        .titleMealPlan{
            display: block;
        }
        #headerContainer{
            padding: 0;
        }
        #detailContainer{
            padding: 0;
            margin-top: 60px;
        }
    }
</style>

<main>
    <div class="site-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <span class="titleMealPlan">Resep</span>
                </div>
            </div>

            <form action="/save_resep" method="post">
                <input type="email" value="malicious-email@example.com">
           
            <div class="row sectionMarign">
                <div class="col-sm-4" id="headerContainer">
                    <div class="row">
                        <div class="col-sm-12">
                            <img class="coverImage" src="<?php echo e($selectResep->cover); ?>" alt="<?php echo e($selectResep->judul_resep); ?>">
                        </div>
                        <div class="col-sm-12">
                            <h3><?php echo e(ucwords(strtolower($selectResep->judul_resep))); ?></h3>
                            <h5 class="textJumlahSajian">Jumlah Sajian: <?php echo e($selectResep->yield); ?></h5>
                            <br>
                            <h5 class="textJumlahSajian">Nutrisi Persajian</h5>
                            <table style="width: 100%;">
                                <tbody>
                                    <?php
                                        foreach (json_decode ($selectResep->digest) as $macros){
                                            if($macros->label == "Fat"){
                                                $fat = ($macros->total)/$selectResep->yield;
                                            }
                                            elseif($macros->label == "Protein"){
                                                $protein = ($macros->total)/$selectResep->yield;
                                            }
                                            elseif($macros->label == "Carbs"){
                                                $carbs = ($macros->total)/$selectResep->yield;
                                            }
                                        }
                                    ?>
                                    <tr>
                                        <td>Kalori</td>
                                        <td align="right"><?php echo e(round(($selectResep->calories/round($selectResep->yield,0)),0)); ?> kcal</td>
                                    </tr>
                                    <tr>
                                        <td>Karbo</td>
                                        <td align="right"><?php echo e(round($carbs, 0)); ?> gram</td>
                                    </tr>
                                    <tr>
                                        <td>Protein</td>
                                        <td align="right"><?php echo e(round($protein, 0)); ?> gram</td>
                                    </tr>
                                    <tr>
                                        <td>Lemak</td>
                                        <td align="right"><?php echo e(round($fat, 0)); ?> gram</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8" id="detailContainer">
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>Bahan</h4>
                            <select class="form-select optionBahan selUser" aria-label="Default select example" name='bahan' id="selcetUSER_1">
                                <?php $__currentLoopData = $list_komposisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bahan->id); ?>" energi="<?php echo e($bahan->energi); ?>" karbo="<?php echo e($bahan->karbo); ?>" protein="<?php echo e($bahan->protein); ?>" lemak="<?php echo e($bahan->lemak); ?>" makanan="<?php echo e($bahan->makanan); ?>"><?php echo e($bahan->nama_komposisi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="button" class="btn btn-info but_read"><i class="fas fa-plus"></i></button>
                        </div>
                        <div class="col-sm-12">
                            <div class="bahanContainer">
                                
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <h4>Langkah </h4>
                            <div class="form-floating">
                                <textarea class="form-control" placeholder="langkah..." id="floatingTextarea2" style="height: 100px"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </form>
            
        </div>
    </div>
</main>

<script>
    // Initialize select2
    $("#selcetUSER_1").select2();

    var counter= 0;

    // Read selected option
    $('.but_read').click(function(){
        counter++;
        var nama = $('#selcetUSER_1 option:selected').text();
        var selectBahan = '<div class="rowBahan" id="containerBahan_'+counter+'">'+
                                    '<input type="nummber" class="form-control bahanQTY" name="bahan_qty" id="bahan_'+counter+'">'+
                                    '<input type="text" class="form-control namaPlace" name="nama_bahan" id="nama_'+counter+'" value="'+nama+'" disabled>'+
                                    '<button type="button" class="btn btn-info deletBtn" index="'+counter+'"><i class="fas fa-trash-alt"></i></button>'+
                                '</div>';

        $( ".bahanContainer" ).append(selectBahan);

        $(".deletBtn").click(function(){
            var index = $(this).attr("index");
            $("#containerBahan_"+index).remove();
        });
    });



    function likeMenu(x){
        var id = x ;
        
        $.ajaxSetup({ 
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        });

        $.ajax({
        url: "<?php echo e(url('/likeMenu')); ?>",
        type: "post",
        data:
        {id:id} ,
        async: true,
        timeout: 40000,
        success: function (response) {
            location.href = "/resep/"+id;
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert("error!");
        }
        });
    }
    function unlikeMenu(x){
        var id = x ;

        $.ajaxSetup({ 
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        });

        $.ajax({
        url: "<?php echo e(url('/unlikeMenu')); ?>",
        type: "post",
        data:
        {id:id} ,
        async: true,
        timeout: 40000,
        success: function (response) {
            location.href = "/resep/"+id;
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert("error!");
        }
        });
    }

    function saveMenu(x){
        var id = x ;
        
        $.ajaxSetup({ 
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        });

        $.ajax({
        url: "<?php echo e(url('/saveMenu')); ?>",
        type: "post",
        data:
        {id:id} ,
        async: true,
        timeout: 40000,
        success: function (response) {
            location.href = "/resep/"+id;
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert("error!");
        }
        });
    }
    function unsaveMenu(x){
        var id = x ;

        $.ajaxSetup({ 
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        });

        $.ajax({
        url: "<?php echo e(url('/unsaveMenu')); ?>",
        type: "post",
        data:
        {id:id} ,
        async: true,
        timeout: 40000,
        success: function (response) {
            location.href = "/resep/"+id;
        },
        error: function(jqXHR, textStatus, errorThrown) {
            alert("error!");
        }
        });
    }
</script>





<?php echo $__env->make('./footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\skripsiNew\resources\views/dashboard/edit_resep.blade.php ENDPATH**/ ?>