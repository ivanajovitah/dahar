<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Pengujian extends Controller
{
    public function egosimilar_v1(){ //pure dengan parameter TDEE BMR

    }

    public function ujiAHP_2(){
        ini_set('max_execution_time', 300000000);
        $umur = [17,21,25,26,30,35,36,40,45];
        $goals = ["maintain","cutting","bulking"];
        // $pref = ["highKarbo","moderateKarbo","lowKarbo"];
        $orientasiMakan = ["normal","vegetarian","vegan"];
        $aktivitas = [1,2,3,4,5];
        $beratCowokRemaja = [49,50,70,71,80,81];
        $beratCowokDewasa = [52,53,70,71,84,85];

        $beratCewekRemaja = [43,44,64,65,76,77];
        $beratCewekDewasa = [46,47,63,64,75,76];

        // echo "<h1>Pria</h1>";
        echo '  <table>
                    <thead>
                        <tr align="center">
                            <th>No</th>
                            <th>TDEE</th>
                            <th>Batas Bawah</th>
                            <th>Batas Atas</th>
                            <th>jumlahPairingAwal</th>
                            <th>jumlahMemenuhiKriteria</th>
                            <th>Total Kalori</th>
                        </tr>
                    </thead>
                
                    <tbody>';
        $co = 1;
        foreach($umur as $usia){
            foreach($goals as $gl){
                foreach($aktivitas as $ak){
                    foreach($orientasiMakan as $om){
                        if($usia == 17){
                            foreach($beratCowokRemaja as $berat){
                                $gen = $this->generate_SET("lowKarbo",168,$berat,$ak,$gl,"M",$usia,$om);
                                // dd($gen);
                                if($gen['rekomen_final']  != null){
                                    foreach($gen['rekomen_final'] as $key => $kalori_hasil){
                                        echo "
                                            <tr>
                                                <td>".$co."</td>
                                                <td>".round($gen['tdee'],0)."</td>
                                                <td>".round($gen['batasBawah_TDEE'],0)."</td>
                                                <td>".round($gen['batasAtas_TDEE'],0)."</td>
                                                <td>".$gen['jumlahPairingAwal']."</td>
                                                <td>".$gen['jumlahMemenuhiKriteria']."</td>
                                                <td>".round($kalori_hasil,2)."</td>
                                            </tr>
                                        ";
                                    }
                                }
                                else{
                                    echo "
                                        <tr>
                                            <td>".$co."</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                        </tr>
                                    ";
                                }
                                $co++;
                            }
                        }
                        else{
                            foreach($beratCowokDewasa as $berat){
                                $gen = $this->generate_SET("lowKarbo",168,$berat,$ak,$gl,"M",$usia,$om);
                                if($gen['rekomen_final']  != null){
                                    foreach($gen['rekomen_final'] as $key => $kalori_hasil){
                                        echo "
                                            <tr>
                                                <td>".$co."</td>
                                                <td>".round($gen['tdee'],0)."</td>
                                                <td>".round($gen['batasBawah_TDEE'],0)."</td>
                                                <td>".round($gen['batasAtas_TDEE'],0)."</td>
                                                <td>".$gen['jumlahPairingAwal']."</td>
                                                <td>".$gen['jumlahMemenuhiKriteria']."</td>
                                                <td>".round($kalori_hasil,2)."</td>
                                            </tr>
                                        ";
                                    }
                                }
                                else{
                                    echo "
                                        <tr>
                                            <td>".$co."</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                        </tr>
                                    ";
                                }
                                $co++;
                            }
                        }
                        
                        
                    }
                }
            }
        }


        foreach($umur as $usia){
            foreach($goals as $gl){
                foreach($aktivitas as $ak){
                    foreach($orientasiMakan as $om){
                        if($usia == 17){
                            foreach($beratCewekRemaja as $berat){
                                $gen = $this->generate_SET("lowKarbo",159,$berat,$ak,$gl,"F",$usia,$om);
                                if($gen['rekomen_final']  != null){
                                    foreach($gen['rekomen_final'] as $key => $kalori_hasil){
                                        echo "
                                            <tr>
                                                <td>".$co."</td>
                                                <td>".round($gen['tdee'],0)."</td>
                                                <td>".round($gen['batasBawah_TDEE'],0)."</td>
                                                <td>".round($gen['batasAtas_TDEE'],0)."</td>
                                                <td>".$gen['jumlahPairingAwal']."</td>
                                                <td>".$gen['jumlahMemenuhiKriteria']."</td>
                                                <td>".round($kalori_hasil,2)."</td>
                                            </tr>
                                        ";
                                    }
                                }
                                else{
                                    echo "
                                        <tr>
                                            <td>".$co."</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                        </tr>
                                    ";
                                }
                                $co++;
                            }
                        }
                        else{
                            foreach($beratCewekDewasa as $berat){
                                $gen = $this->generate_SET("lowKarbo",159,$berat,$ak,$gl,"M",$usia,$om);
                                if($gen['rekomen_final']  != null){
                                    foreach($gen['rekomen_final'] as $key => $kalori_hasil){
                                        echo "
                                            <tr>
                                                <td>".$co."</td>
                                                <td>".round($gen['tdee'],0)."</td>
                                                <td>".round($gen['batasBawah_TDEE'],0)."</td>
                                                <td>".round($gen['batasAtas_TDEE'],0)."</td>
                                                <td>".$gen['jumlahPairingAwal']."</td>
                                                <td>".$gen['jumlahMemenuhiKriteria']."</td>
                                                <td>".round($kalori_hasil,2)."</td>
                                            </tr>
                                        ";
                                    }
                                }
                                else{
                                    echo "
                                        <tr>
                                            <td>".$co."</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                        </tr>
                                    ";
                                }
                                $co++;
                            }
                        }
                    }
                }
            }
        }
        echo"</tbody>
        </table>";
    }

    
    public function generate_SET($komposisi, $tb, $bb, $aktifitas, $goal, $gender,$usia, $orinetasiMakan){
        $nutrisi = $this -> getTDEE($tb, $bb, $aktifitas, $goal, $gender,$usia);

        $pref = $orinetasiMakan;

        $komposisiPilih = $komposisi;

        $AHP_Breakfast = $this->AHP_SORT_SET($nutrisi['tdeeBersih'],$pref,$komposisiPilih,"breakfast");
        $AHP_Lunch = $this->AHP_SORT_SET($nutrisi['tdeeBersih'],$pref,$komposisiPilih,"lunch");
        $AHP_Dinner = $this->AHP_SORT_SET($nutrisi['tdeeBersih'],$pref,$komposisiPilih,"dinner");

        $list_Breakfast = $AHP_Breakfast;
        $list_Lunch = $AHP_Lunch;
        $list_Dinner = $AHP_Dinner;


        $setBaru = array();
        $dataSetBaru = array();

        foreach($list_Breakfast as $menuBreakfast){
            foreach($list_Lunch as $menuLunch){
                foreach($list_Dinner as $menuDinner){
                    $b_karbo = $menuBreakfast['macro']['karbo'] * 4;
                    $b_protein = $menuBreakfast['macro']['protein'] * 4;
                    $b_lemak = $menuBreakfast['macro']['lemak'] * 9;
                    $b_kalori = $b_karbo + $b_lemak + $b_protein;

                    $l_karbo = $menuLunch['macro']['karbo'] * 4;
                    $l_protein = $menuLunch['macro']['protein'] * 4;
                    $l_lemak = $menuLunch['macro']['lemak'] * 9;
                    $l_kalori = $l_karbo + $l_lemak + $l_protein;

                    $d_karbo = $menuDinner['macro']['karbo'] * 4;
                    $d_protein = $menuDinner['macro']['protein'] * 4;
                    $d_lemak = $menuDinner['macro']['lemak'] * 9;
                    $d_kalori = $d_karbo + $d_lemak + $d_protein;

                    $kalori_set = $b_kalori + $l_kalori + $d_kalori;

                    $b_data = array(
                        "data_resep"=>$menuBreakfast,
                        "karbo"=>$b_karbo, 
                        "protein" => $b_protein, 
                        "fat" => $b_lemak, 
                        "kalori" => $b_kalori
                    );

                    $l_data = array(
                        "data_resep"=>$menuLunch,
                        "karbo"=>$l_karbo, 
                        "protein" => $l_protein, 
                        "fat" => $l_lemak, 
                        "kalori" => $l_kalori
                    );

                    $d_data = array(
                        "data_resep"=>$menuDinner,
                        "karbo"=>$d_karbo, 
                        "protein" => $d_protein, 
                        "fat" => $d_lemak, 
                        "kalori" => $d_kalori
                    );

                    $dataSET = array(
                        "breakfast"=>$b_data,
                        "lunch"=>$l_data,
                        "dinner"=>$d_data,
                    );
                    array_push($setBaru,$kalori_set);
                    array_push($dataSetBaru,$dataSET);
                }
            }
        }

        $jumlahPairingAwal = count($setBaru);

        $batasAtas_TDEE = $nutrisi['tdeeBersih']+($nutrisi['tdeeBersih']*(10/100));
        $batasBawah_TDEE = $nutrisi['tdeeBersih']-($nutrisi['tdeeBersih']*(10/100));
        $setMemenuhi_kriteria = array();
        foreach($setBaru as $key => $set){
            if( ($set >= $batasBawah_TDEE) && ($set <= $batasAtas_TDEE)){
                array_push($setMemenuhi_kriteria,$key);
            }
        }
        $jumlahMemenuhiKriteria = count($setMemenuhi_kriteria);

        //Randome Pick 10
        if(count($setMemenuhi_kriteria)!= 0){
            if(count($setMemenuhi_kriteria)<10){
                $jumlahRand = count($setMemenuhi_kriteria);
                // dapat Arraynya
                $rand_keys = array_rand($setMemenuhi_kriteria, $jumlahRand);
                $sampleMenu = [];
                foreach($rand_keys as $index){
                    array_push($sampleMenu, $setMemenuhi_kriteria[$index]);
                }
            }
            else{
                $jumlahRand = 10;
                // dapat Arraynya
                $rand_keys = array_rand($setMemenuhi_kriteria, $jumlahRand);
                $sampleMenu = [];
                foreach($rand_keys as $index){
                    array_push($sampleMenu, $setMemenuhi_kriteria[$index]);
                }
            }
            $rekomen_final = array();
            $rekomen_final_detail = array();

            foreach($sampleMenu as $index){
                array_push($rekomen_final, $setBaru[$index]);
                array_push($rekomen_final_detail, $dataSetBaru[$index]);
            }

            return [
                'rekomen_final'=> $rekomen_final, 
                "rekomen_final_detail" => $rekomen_final_detail, 
                "jumlahPairingAwal" => $jumlahPairingAwal,
                'jumlahMemenuhiKriteria' => $jumlahMemenuhiKriteria,
                'tdee' => $nutrisi['tdeeBersih'],
                'batasAtas_TDEE'=> $batasAtas_TDEE,
                'batasBawah_TDEE' => $batasBawah_TDEE
            ];
        }
        else{
            return ['rekomen_final'=> null, "rekomen_final_detail" => null];
        }
        
        

        
    }
    public function AHP_SORT_SET($TDEE, $preferance, $tipe_limitProfile,$template_group){
        $tdee = $TDEE;
        $pref = $preferance;
        $pilihTipe = $tipe_limitProfile;
        $groupTemplate = $template_group;

        $limitinProfileTipe = array( // karbohidrat , protein, lemak
            "highKarbo" => array(
                "karbo" => round((($tdee * (50/100))/4),3),
                "protein" => round((($tdee * (30/100))/4),3),
                "lemak" => round((($tdee * (20/100))/9),3),
            ),
            "moderateKarbo" => array(
                "karbo" => round((($tdee * (35/100))/4),3),
                "protein" => round((($tdee * (30/100))/4),3),
                "lemak" => round((($tdee * (35/100))/9),3),
            ),
            "lowKarbo" => array(
                "karbo" => round((($tdee * (20/100))/4),3),
                "protein" => round((($tdee * (40/100))/4),3),
                "lemak" => round((($tdee * (40/100))/9),3),
            ),
        );

        $selectResep = "";

        if ($pref == "normal"){
            $selectResep =  DB::table('list_resep')
                            ->select(
                                'id','judul_resep','cover','healthLabels','calories',
                                'yield','totalTime', 'cuisineType','digest','score','likes')
                            ->where('cuisineType', 'LIKE', '%'.$groupTemplate.'%')
                            ->get();
        }
        elseif($pref == "vegetarian"){
            $selectResep =  DB::table('list_resep')
                            ->select(
                                'id','judul_resep','cover','healthLabels','calories',
                                'yield','totalTime', 'cuisineType','digest','score','likes')
                            ->where('healthLabels', 'LIKE', '%vegetarian%')
                            ->where('cuisineType', 'LIKE', '%'.$groupTemplate.'%')
                            ->get();
        }
        elseif($pref == "vegan"){
            $selectResep =  DB::table('list_resep')
                            ->select(
                                'id','judul_resep','cover','healthLabels','calories',
                                'yield','totalTime', 'cuisineType','digest','score','likes')
                            ->where('healthLabels', 'LIKE', '%vegan%')
                            ->where('cuisineType', 'LIKE', '%'.$groupTemplate.'%')
                            ->get();
        }

        // Bobot Kriteria
        //BOBOT DIBIKIN BUAT MASING" KRITERIA
        if($pilihTipe == "highKarbo"){
            $W_karbo = 0.539;
            $W_protein = 0.297;
            $W_lemak = 0.164;
        }
        elseif($pilihTipe == "moderateKarbo"){
            $W_karbo = 0.297;
            $W_protein = 0.164;
            $W_lemak = 0.539;
        }
        elseif($pilihTipe == "lowKarbo"){
            $W_karbo = 0.142;
            $W_protein = 0.525;
            $W_lemak = 0.334;
        }

        // DATA RESEP
        $listResepIdentity = [];
        $alternatifResep = [];
        //Limiting Profile
        $limitProfile = $limitinProfileTipe[$pilihTipe];
        //Local Priorities List
        $appropriate = [];
        $in_appropriate = [];
        //List Menu Recommended
        $menuRecomen = [];

        foreach ($selectResep as $resepSatuan) {
            $idResep = $resepSatuan->id;
            $judulResep = $resepSatuan->judul_resep;
            $coverResep = $resepSatuan->cover;
            $healthLabelsResep = $resepSatuan->healthLabels;
            $totalTimeResep = $resepSatuan->totalTime;
            $cuisineTypeResep = $resepSatuan->cuisineType;
            $jumlahServingResep =  $resepSatuan->yield;
            $caloriesResep = ($resepSatuan->calories)/$jumlahServingResep;
            $likesResep = $resepSatuan->likes;

            $fat = "";
            $protein = "";
            $carbs = "";
            foreach (json_decode ($resepSatuan->digest) as $macros){
                if($macros->label == "Fat"){
                   $fat = ($macros->total)/$jumlahServingResep;
                }
                elseif($macros->label == "Protein"){
                    $protein = ($macros->total)/$jumlahServingResep;
                }
                elseif($macros->label == "Carbs"){
                    $carbs = ($macros->total)/$jumlahServingResep;
                }
            }

            $resepKarakter = array(
                'idResep'=> $idResep,
                'karbo'=> $carbs,
                'lemak'=> $fat,
                'protein'=> $protein,
            );

            $resepIdentity = array(
                'idResep'=> $idResep,
                'judul_resep'=> $judulResep,
                'cover'=> $coverResep,
                'healthLabels'=> $healthLabelsResep,
                'calories'=> $caloriesResep,
                'totalWeight'=> $jumlahServingResep,
                'totalTime'=> $totalTimeResep,
                'cuisineTypeResep'=> $cuisineTypeResep,
                'likesResep'=> $likesResep,
                'macro' => $resepKarakter,
            );

             

            if($fat == 0){
                $fat = 1;
            }
            if($protein == 0){
                $protein = 1;
            }
            if($carbs == 0){
                $carbs = 1;
            }
            
            
            //////////
            //start cari local priorities alternatif // karbo , protein , lemak
            //matrix alternatif
            $a_m = array( 
                array(1,($limitProfile["karbo"]/$carbs),($limitProfile["lemak"]/$carbs)),
                array(($limitProfile["karbo"]/$protein),1,($limitProfile["lemak"]/$protein)),
                array(($limitProfile["karbo"]/$fat),($limitProfile["protein"]/$fat),1),
            );
            //total kolom
            $tk_a = array( 
                ($a_m[0][0]+$a_m[1][0]+$a_m[2][0]),
                ($a_m[0][1]+$a_m[1][1]+$a_m[2][1]),
                ($a_m[0][2]+$a_m[1][2]+$a_m[2][2])
            );
            //normal matrix alternatif
            $norm_a_m= array(
                array(($a_m[0][0]/$tk_a[0]),($a_m[0][1]/$tk_a[1]),($a_m[0][2]/$tk_a[2])),
                array(($a_m[1][0]/$tk_a[0]),($a_m[1][1]/$tk_a[1]),($a_m[1][2]/$tk_a[2])),
                array(($a_m[2][0]/$tk_a[0]),($a_m[2][1]/$tk_a[1]),($a_m[2][2]/$tk_a[2])),
            );
            //local priorties alternatif
            $lp_a = array( 
                ($norm_a_m[0][0]+$norm_a_m[0][1]+$norm_a_m[0][2])/3,
                ($norm_a_m[1][0]+$norm_a_m[1][1]+$norm_a_m[1][2])/3,
                ($norm_a_m[2][0]+$norm_a_m[2][1]+$norm_a_m[2][2])/3,
            );
            //end cari local priorities alternatif
            //////////
            

            //////////
            //start cari local priorities limit profile
            //matrix limit profile
            $lp_m = array( // karbo , protein , lemak
                array(1,$protein/($limitProfile["karbo"]),($fat/$limitProfile["karbo"])),
                array(($carbs/$limitProfile["protein"]),1,($fat/$limitProfile["protein"])),
                array(($carbs/$limitProfile["lemak"]),($protein/$limitProfile["lemak"]),1),
            );
            //total kolom
            $tk_lp = array( 
                ($lp_m[0][0]+$lp_m[1][0]+$lp_m[2][0]),
                ($lp_m[0][1]+$lp_m[1][1]+$lp_m[2][1]),
                ($lp_m[0][2]+$lp_m[1][2]+$lp_m[2][2])
            );
            //normal matrix limit profile
            $norm_lp_m= array(
                array(($lp_m[0][0]/$tk_lp[0]),($lp_m[0][1]/$tk_lp[1]),($lp_m[0][2]/$tk_lp[2])),
                array(($lp_m[1][0]/$tk_lp[0]),($lp_m[1][1]/$tk_lp[1]),($lp_m[1][2]/$tk_lp[2])),
                array(($lp_m[2][0]/$tk_lp[0]),($lp_m[2][1]/$tk_lp[1]),($lp_m[2][2]/$tk_lp[2])),
            );
            //local priorties limit profile
            $lp_lp = array( 
                ($norm_lp_m[0][0]+$norm_lp_m[0][1]+$norm_lp_m[0][2])/3,
                ($norm_lp_m[1][0]+$norm_lp_m[1][1]+$norm_lp_m[1][2])/3,
                ($norm_lp_m[2][0]+$norm_lp_m[2][1]+$norm_lp_m[2][2])/3,
            );
            //end cari local priorities limit profile
            //////////

            //Overall Scor
            $P_a = round(($lp_a[0]*$W_karbo) +($lp_a[1]*$W_protein) + ($lp_a[2]*$W_lemak),3);
            $P_lp = round(($lp_lp[0]*$W_karbo) +($lp_lp[1]*$W_protein) + ($lp_lp[2]*$W_lemak),3);

            // blm di sort berdasarkan nilai
            if($P_lp > $P_a){//appropriate
                array_push($appropriate,array('score_a'=>$P_a, 'score_lp'=>$P_lp, 'idResep'=>$idResep, ''));
            }
            else{// inappropriate
                array_push($in_appropriate,$idResep);
            }
            
            array_push($listResepIdentity,$resepIdentity);
            array_push($alternatifResep,$resepKarakter);
        }

        foreach($appropriate as $theID){
            foreach($listResepIdentity as $resepComplete){
                if($theID['idResep'] == $resepComplete['idResep']){
                    array_push($menuRecomen, $resepComplete);
                } 
            }
        }

        
        return $menuRecomen;
        // return dd($menuRecomen);
    }


    //START UJI BIASA
    public function ujiAHP_1(){
        ini_set('max_execution_time', 300000000);
        $umur = [17,21,25,26,30,35,36,40,45];
        $goals = ["maintain","cutting","bulking"];
        // $pref = ["highKarbo","moderateKarbo","lowKarbo"];
        $orientasiMakan = ["normal","vegetarian","vegan"];
        $aktivitas = [1,2,3,4,5];
        $beratCowokRemaja = [49,50,70,71,80,81];
        $beratCowokDewasa = [52,53,70,71,84,85];

        $beratCewekRemaja = [43,44,64,65,76,77];
        $beratCewekDewasa = [46,47,63,64,75,76];

        // echo "<h1>Pria</h1>";
        echo '  <table>
                    <thead>
                        <tr align="center">
                            <th>No</th>
                            <th>Gender</th>
                            <th>Tinggi</th>
                            <th>Usia</th>
                            <th>Berat</th>
                            <th>Goals</th>
                            <th>Aktivitas</th>
                            <th>TDEE</th>
                            <th>Orientasi</th>
                            <th>Untuk</th>
                            <th>Karbo</th>
                            <th>Protein</th>
                            <th>Lemak</th>
                        </tr>
                    </thead>
                
                    <tbody>';
        $co = 1;
        foreach($umur as $usia){
            foreach($goals as $gl){
                foreach($aktivitas as $ak){
                    foreach($orientasiMakan as $om){
                        if($usia == 17){
                            foreach($beratCowokRemaja as $berat){
                                $gen = $this->generate("lowKarbo",168,$berat,$ak,$gl,"M",$usia,$om);
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Pria</td>
                                    <td>168</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(168,$berat,$ak,$gl,'M',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Breakfast</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['karbo']) ? 0 : round($gen['list_Breakfast'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['protein']) ? 0 : round($gen['list_Breakfast'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['lemak']) ? 0 : round($gen['list_Breakfast'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Pria</td>
                                    <td>168</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(168,$berat,$ak,$gl,'M',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Lunch</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['karbo']) ? 0 : round($gen['list_Lunch'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['protein']) ? 0 : round($gen['list_Lunch'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['lemak']) ? 0 : round($gen['list_Lunch'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Pria</td>
                                    <td>168</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(168,$berat,$ak,$gl,'M',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Dinner</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['karbo']) ? 0 : round($gen['list_Dinner'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['protein']) ? 0 : round($gen['list_Dinner'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['lemak']) ? 0 : round($gen['list_Dinner'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                            }
                        }
                        else{
                            foreach($beratCowokDewasa as $berat){
                                $gen = $this->generate("lowKarbo",168,$berat,$ak,$gl,"M",$usia,$om);
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Pria</td>
                                    <td>168</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(168,$berat,$ak,$gl,'M',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Breakfast</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['karbo']) ? 0 : round($gen['list_Breakfast'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['protein']) ? 0 : round($gen['list_Breakfast'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['lemak']) ? 0 : round($gen['list_Breakfast'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Pria</td>
                                    <td>168</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(168,$berat,$ak,$gl,'M',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Lunch</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['karbo']) ? 0 : round($gen['list_Lunch'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['protein']) ? 0 : round($gen['list_Lunch'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['lemak']) ? 0 : round($gen['list_Lunch'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Pria</td>
                                    <td>168</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(168,$berat,$ak,$gl,'M',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Dinner</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['karbo']) ? 0 : round($gen['list_Dinner'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['protein']) ? 0 : round($gen['list_Dinner'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['lemak']) ? 0 : round($gen['list_Dinner'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                            }
                        }
                        
                        
                    }
                }
            }
        }


        foreach($umur as $usia){
            foreach($goals as $gl){
                foreach($aktivitas as $ak){
                    foreach($orientasiMakan as $om){
                        if($usia == 17){
                            foreach($beratCewekRemaja as $berat){
                                $gen = $this->generate("lowKarbo",159,$berat,$ak,$gl,"F",$usia,$om);
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Wanita</td>
                                    <td>159</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(159,$berat,$ak,$gl,'F',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Breakfast</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['karbo']) ? 0 : round($gen['list_Breakfast'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['protein']) ? 0 : round($gen['list_Breakfast'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['lemak']) ? 0 : round($gen['list_Breakfast'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Wanita</td>
                                    <td>159</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(159,$berat,$ak,$gl,'F',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Lunch</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['karbo']) ? 0 : round($gen['list_Lunch'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['protein']) ? 0 : round($gen['list_Lunch'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['lemak']) ? 0 : round($gen['list_Lunch'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Wanita</td>
                                    <td>159</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(159,$berat,$ak,$gl,'F',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Dinner</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['karbo']) ? 0 : round($gen['list_Dinner'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['protein']) ? 0 : round($gen['list_Dinner'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['lemak']) ? 0 : round($gen['list_Dinner'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                            }
                        }
                        else{
                            foreach($beratCewekDewasa as $berat){
                                $gen = $this->generate("lowKarbo",159,$berat,$ak,$gl,"M",$usia,$om);
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Wanita</td>
                                    <td>159</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(159,$berat,$ak,$gl,'F',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Breakfast</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['karbo']) ? 0 : round($gen['list_Breakfast'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['protein']) ? 0 : round($gen['list_Breakfast'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Breakfast'][0]['macro']['lemak']) ? 0 : round($gen['list_Breakfast'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Wanita</td>
                                    <td>159</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(159,$berat,$ak,$gl,'F',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Lunch</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['karbo']) ? 0 : round($gen['list_Lunch'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['protein']) ? 0 : round($gen['list_Lunch'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Lunch'][0]['macro']['lemak']) ? 0 : round($gen['list_Lunch'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                                echo "
                                    <tr>
                                    <td>".$co."</td>
                                    <td>Wanita</td>
                                    <td>159</td>
                                    <td>".$usia."</td>
                                    <td>".$berat."</td>
                                    <td>".$gl."</td>
                                    <td>".$ak."</td>
                                    <td>".($this->getTDEE(159,$berat,$ak,$gl,'F',$usia))['tdeeBersih']."</td>
                                    <td>".$om."</td>
                                    <td>Dinner</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['karbo']) ? 0 : round($gen['list_Dinner'][0]['macro']['karbo'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['protein']) ? 0 : round($gen['list_Dinner'][0]['macro']['protein'],0))."</td>
                                    <td>".(empty($gen['list_Dinner'][0]['macro']['lemak']) ? 0 : round($gen['list_Dinner'][0]['macro']['lemak'],0))."</td>
                                    </tr>
                                ";
                                $co++;
                            }
                        }
                    }
                }
            }
        }
        echo"</tbody>
        </table>";
    }

    public function generate($komposisi, $tb, $bb, $aktifitas, $goal, $gender,$usia, $orinetasiMakan){
        $nutrisi = $this -> getTDEE($tb, $bb, $aktifitas, $goal, $gender,$usia);

        $pref = $orinetasiMakan;

        $komposisiPilih = $komposisi;

        $AHP_Breakfast = $this->AHP_SORT($nutrisi['tdeeBersih'],$pref,$komposisiPilih,"breakfast");
        $AHP_Lunch = $this->AHP_SORT($nutrisi['tdeeBersih'],$pref,$komposisiPilih,"lunch");
        $AHP_Dinner = $this->AHP_SORT($nutrisi['tdeeBersih'],$pref,$komposisiPilih,"dinner");

        $list_Breakfast = $AHP_Breakfast;
        $list_Lunch = $AHP_Lunch;
        $list_Dinner = $AHP_Dinner;
        

        return 
            [   'list_Breakfast'=> $list_Breakfast,
                'list_Lunch'=> $list_Lunch,
                'list_Dinner'=> $list_Dinner,
            ];
    }
    
    public function AHP_SORT($TDEE, $preferance, $tipe_limitProfile,$template_group){
        $tdee = $TDEE;
        $pref = $preferance;
        $pilihTipe = $tipe_limitProfile;
        $groupTemplate = $template_group;

        $limitinProfileTipe = array( // karbohidrat , protein, lemak
            "highKarbo" => array(
                "karbo" => round((($tdee * (50/100))/4),3),
                "protein" => round((($tdee * (30/100))/4),3),
                "lemak" => round((($tdee * (20/100))/9),3),
            ),
            "moderateKarbo" => array(
                "karbo" => round((($tdee * (35/100))/4),3),
                "protein" => round((($tdee * (30/100))/4),3),
                "lemak" => round((($tdee * (35/100))/9),3),
            ),
            "lowKarbo" => array(
                "karbo" => round((($tdee * (20/100))/4),3),
                "protein" => round((($tdee * (40/100))/4),3),
                "lemak" => round((($tdee * (40/100))/9),3),
            ),
        );

        $selectResep = "";

        if ($pref == "normal"){
            $selectResep =  DB::table('list_resep')
                            ->select(
                                'id','judul_resep','cover','healthLabels','calories',
                                'yield','totalTime', 'cuisineType','digest','score','likes')
                            ->where('cuisineType', 'LIKE', '%'.$groupTemplate.'%')
                            ->get();
        }
        elseif($pref == "vegetarian"){
            $selectResep =  DB::table('list_resep')
                            ->select(
                                'id','judul_resep','cover','healthLabels','calories',
                                'yield','totalTime', 'cuisineType','digest','score','likes')
                            ->where('healthLabels', 'LIKE', '%vegetarian%')
                            ->where('cuisineType', 'LIKE', '%'.$groupTemplate.'%')
                            ->get();
        }
        elseif($pref == "vegan"){
            $selectResep =  DB::table('list_resep')
                            ->select(
                                'id','judul_resep','cover','healthLabels','calories',
                                'yield','totalTime', 'cuisineType','digest','score','likes')
                            ->where('healthLabels', 'LIKE', '%vegan%')
                            ->where('cuisineType', 'LIKE', '%'.$groupTemplate.'%')
                            ->get();
        }

        // Bobot Kriteria
        //BOBOT DIBIKIN BUAT MASING" KRITERIA
        if($pilihTipe == "highKarbo"){
            $W_karbo = 0.539;
            $W_protein = 0.297;
            $W_lemak = 0.164;
        }
        elseif($pilihTipe == "moderateKarbo"){
            $W_karbo = 0.297;
            $W_protein = 0.164;
            $W_lemak = 0.539;
        }
        elseif($pilihTipe == "lowKarbo"){
            $W_karbo = 0.142;
            $W_protein = 0.525;
            $W_lemak = 0.334;
        }

        // DATA RESEP
        $listResepIdentity = [];
        $alternatifResep = [];
        //Limiting Profile
        $limitProfile = $limitinProfileTipe[$pilihTipe];
        //Local Priorities List
        $appropriate = [];
        $in_appropriate = [];
        //List Menu Recommended
        $menuRecomen = [];

        foreach ($selectResep as $resepSatuan) {
            $idResep = $resepSatuan->id;
            $judulResep = $resepSatuan->judul_resep;
            $coverResep = $resepSatuan->cover;
            $healthLabelsResep = $resepSatuan->healthLabels;
            $totalTimeResep = $resepSatuan->totalTime;
            $cuisineTypeResep = $resepSatuan->cuisineType;
            $jumlahServingResep =  $resepSatuan->yield;
            $caloriesResep = ($resepSatuan->calories)/$jumlahServingResep;
            $likesResep = $resepSatuan->likes;

            $fat = "";
            $protein = "";
            $carbs = "";
            foreach (json_decode ($resepSatuan->digest) as $macros){
                if($macros->label == "Fat"){
                   $fat = ($macros->total)/$jumlahServingResep;
                }
                elseif($macros->label == "Protein"){
                    $protein = ($macros->total)/$jumlahServingResep;
                }
                elseif($macros->label == "Carbs"){
                    $carbs = ($macros->total)/$jumlahServingResep;
                }
            }

            $resepKarakter = array(
                'idResep'=> $idResep,
                'karbo'=> $carbs,
                'lemak'=> $fat,
                'protein'=> $protein,
            );

            $resepIdentity = array(
                'idResep'=> $idResep,
                'judul_resep'=> $judulResep,
                'cover'=> $coverResep,
                'healthLabels'=> $healthLabelsResep,
                'calories'=> $caloriesResep,
                'totalWeight'=> $jumlahServingResep,
                'totalTime'=> $totalTimeResep,
                'cuisineTypeResep'=> $cuisineTypeResep,
                'likesResep'=> $likesResep,
                'macro' => $resepKarakter,
            );

             

            if($fat == 0){
                $fat = 1;
            }
            if($protein == 0){
                $protein = 1;
            }
            if($carbs == 0){
                $carbs = 1;
            }
            
            
            //////////
            //start cari local priorities alternatif // karbo , protein , lemak
            //matrix alternatif
            $a_m = array( 
                array(1,($limitProfile["karbo"]/$carbs),($limitProfile["lemak"]/$carbs)),
                array(($limitProfile["karbo"]/$protein),1,($limitProfile["lemak"]/$protein)),
                array(($limitProfile["karbo"]/$fat),($limitProfile["protein"]/$fat),1),
            );
            //total kolom
            $tk_a = array( 
                ($a_m[0][0]+$a_m[1][0]+$a_m[2][0]),
                ($a_m[0][1]+$a_m[1][1]+$a_m[2][1]),
                ($a_m[0][2]+$a_m[1][2]+$a_m[2][2])
            );
            //normal matrix alternatif
            $norm_a_m= array(
                array(($a_m[0][0]/$tk_a[0]),($a_m[0][1]/$tk_a[1]),($a_m[0][2]/$tk_a[2])),
                array(($a_m[1][0]/$tk_a[0]),($a_m[1][1]/$tk_a[1]),($a_m[1][2]/$tk_a[2])),
                array(($a_m[2][0]/$tk_a[0]),($a_m[2][1]/$tk_a[1]),($a_m[2][2]/$tk_a[2])),
            );
            //local priorties alternatif
            $lp_a = array( 
                ($norm_a_m[0][0]+$norm_a_m[0][1]+$norm_a_m[0][2])/3,
                ($norm_a_m[1][0]+$norm_a_m[1][1]+$norm_a_m[1][2])/3,
                ($norm_a_m[2][0]+$norm_a_m[2][1]+$norm_a_m[2][2])/3,
            );
            //end cari local priorities alternatif
            //////////
            

            //////////
            //start cari local priorities limit profile
            //matrix limit profile
            $lp_m = array( // karbo , protein , lemak
                array(1,$protein/($limitProfile["karbo"]),($fat/$limitProfile["karbo"])),
                array(($carbs/$limitProfile["protein"]),1,($fat/$limitProfile["protein"])),
                array(($carbs/$limitProfile["lemak"]),($protein/$limitProfile["lemak"]),1),
            );
            //total kolom
            $tk_lp = array( 
                ($lp_m[0][0]+$lp_m[1][0]+$lp_m[2][0]),
                ($lp_m[0][1]+$lp_m[1][1]+$lp_m[2][1]),
                ($lp_m[0][2]+$lp_m[1][2]+$lp_m[2][2])
            );
            //normal matrix limit profile
            $norm_lp_m= array(
                array(($lp_m[0][0]/$tk_lp[0]),($lp_m[0][1]/$tk_lp[1]),($lp_m[0][2]/$tk_lp[2])),
                array(($lp_m[1][0]/$tk_lp[0]),($lp_m[1][1]/$tk_lp[1]),($lp_m[1][2]/$tk_lp[2])),
                array(($lp_m[2][0]/$tk_lp[0]),($lp_m[2][1]/$tk_lp[1]),($lp_m[2][2]/$tk_lp[2])),
            );
            //local priorties limit profile
            $lp_lp = array( 
                ($norm_lp_m[0][0]+$norm_lp_m[0][1]+$norm_lp_m[0][2])/3,
                ($norm_lp_m[1][0]+$norm_lp_m[1][1]+$norm_lp_m[1][2])/3,
                ($norm_lp_m[2][0]+$norm_lp_m[2][1]+$norm_lp_m[2][2])/3,
            );
            //end cari local priorities limit profile
            //////////

            //Overall Scor
            $P_a = round(($lp_a[0]*$W_karbo) +($lp_a[1]*$W_protein) + ($lp_a[2]*$W_lemak),3);
            $P_lp = round(($lp_lp[0]*$W_karbo) +($lp_lp[1]*$W_protein) + ($lp_lp[2]*$W_lemak),3);

            // blm di sort berdasarkan nilai
            if($P_lp > $P_a){//appropriate
                array_push($appropriate,array('score_a'=>$P_a, 'score_lp'=>$P_lp, 'idResep'=>$idResep));
            }
            else{// inappropriate
                array_push($in_appropriate,$idResep);
            }
            
            array_push($listResepIdentity,$resepIdentity);
            array_push($alternatifResep,$resepKarakter);
        }

        

        ////PICK RANDOM 10
        //Membuat List Resep Dengan Data Complete
        if(count($appropriate)>0){
            foreach($appropriate as $theID){
                foreach($listResepIdentity as $resepComplete){
                    if($theID['idResep'] == $resepComplete['idResep']){
                        array_push($menuRecomen, $resepComplete);
                    } 
                }
            }
            //Randome Pick 10
            $jumlahRand = 10;
            if(count($menuRecomen)<10){
                $jumlahRand = count($menuRecomen);
            }
            
            // dapat Arraynya
            $rand_keys = (array)array_rand($menuRecomen, $jumlahRand);
            $sampleMenu = [];
            foreach($rand_keys as $index){
                array_push($sampleMenu, $menuRecomen[$index]);
            }
            $menuRecomen = $sampleMenu;
        }
        else{
            $menuRecomen = null;
        }
        

        
        return $menuRecomen;
        // return dd($menuRecomen);
    }
    //END UJI BIASA



    public function getTDEE($tb, $bb, $aktifitas, $goal, $gender,$usia){
        $tinggiBadan = $tb;
        $beratBadan = $bb;
        $tingkat_aktivitas = $aktifitas;
        $goal = $goal;
        $gender = $gender;
        $usia = $usia;

        $bmr = "";
        $tdee = "";
        //BMR
        if($gender == "M"){
            $bmr = (10 * $beratBadan) + (6.25 * $tinggiBadan) - (5 * $usia) + 5;
        }
        elseif($gender == "F"){
            $bmr = (10 * $beratBadan) + (6.25 * $tinggiBadan) - (5 * $usia) - 161;
        }

        //tdee bersih
        if($tingkat_aktivitas == 1){
            $tdee = $bmr * 1.2;
        }
        elseif($tingkat_aktivitas == 2){
            $tdee = $bmr * 1.37;
        }
        elseif($tingkat_aktivitas == 3){
            $tdee = $bmr * 1.55;
        }
        elseif($tingkat_aktivitas == 4){
            $tdee = $bmr * 1.725;
        }
        elseif($tingkat_aktivitas == 5){
            $tdee = $bmr * 1.9;
        }

        //tdee goal
        if($goal == 'maintain'){
            $tdeeBersih = $tdee;
        }
        elseif($goal == 'cutting'){
            $tdeeBersih = $tdee - 500;
        }
        elseif($goal == 'bulking'){
            $tdeeBersih = $tdee + 500;
        }

        return array('bmr'=>$bmr, 'tdee'=>$tdee, 'tdeeBersih'=>$tdeeBersih, 'usia'=>$usia);
        
    }
}


